<?php
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('commandes.index');
});

Route::get('/commandes', function () {
    return view('commandes.index');
});