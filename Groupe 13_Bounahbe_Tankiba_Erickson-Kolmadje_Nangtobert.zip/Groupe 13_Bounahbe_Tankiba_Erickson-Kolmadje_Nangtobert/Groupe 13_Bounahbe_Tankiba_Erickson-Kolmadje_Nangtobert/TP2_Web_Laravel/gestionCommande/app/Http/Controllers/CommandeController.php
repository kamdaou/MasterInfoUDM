<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;

class CommandeController extends Controller {
    public function index() {
        $commandes = [
            ['id'=>'#CMD-1024','client'=>'Sophie Martin','date'=>'12/10/2024','montant'=>'350,00 €','statut'=>'Livrée'],
            ['id'=>'#CMD-1023','client'=>'Lucas Bernard','date'=>'12/10/2024','montant'=>'120,50 €','statut'=>'En cours'],
            ['id'=>'#CMD-1022','client'=>'Emma Dubois','date'=>'11/10/2024','montant'=>'89,00 €','statut'=>'En attente'],
            ['id'=>'#CMD-1021','client'=>'Paul Lefevre','date'=>'10/10/2024','montant'=>'540,00 €','statut'=>'Livrée'],
            ['id'=>'#CMD-1020','client'=>'Camille Renault','date'=>'09/10/2024','montant'=>'210,00 €','statut'=>'Annulée'],
        ];
        return view('commandes.index', compact('commandes'));
    }
}