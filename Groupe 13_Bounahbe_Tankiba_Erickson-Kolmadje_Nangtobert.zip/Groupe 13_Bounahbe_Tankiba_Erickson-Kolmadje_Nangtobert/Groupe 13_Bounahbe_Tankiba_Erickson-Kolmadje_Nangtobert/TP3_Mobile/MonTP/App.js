import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, TextInput, Modal } from 'react-native';

const INITIAL_PRODUITS = [
  { id: '1', nom: 'iPhone 15 Pro', prix: 580000, prixText: '580 000 FCFA', stock: 2, image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=500', cat: 'Téléphone', color: '#EEF2FF' },
  { id: '2', nom: 'MacBook Air M2', prix: 750000, prixText: '750 000 FCFA', stock: 1, image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=500', cat: 'Ordinateur', color: '#F0FDF4' },
  { id: '3', nom: 'AirPods Pro', prix: 85000, prixText: '85 000 FCFA', stock: 10, image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=500', cat: 'Accessoire', color: '#FFFBEB' },
  { id: '4', nom: 'Samsung S24', prix: 450000, prixText: '450 000 FCFA', stock: 5, image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=500', cat: 'Téléphone', color: '#FEF2F2' },
];

const INITIAL_CLIENTS = [
  { id: '1', nom: 'Erickson N.', city: "N'Djamena", tel: '235 90 00 00 00', initials: 'EN', color: '#4F46E5' },
  { id: '2', nom: 'Moussa', city: 'Moundou', tel: '235 91 11 22 33', initials: 'M', color: '#10B981' },
];

export default function App() {
  const [produits, setProduits] = useState(INITIAL_PRODUITS);
  const [commandes, setCommandes] = useState([]);
  const [page, setPage] = useState('dashboard');
  const [showForm, setShowForm] = useState(false);
  const [showProdForm, setShowProdForm] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState({ id: null, type: null, nom: '' });
  const [editProd, setEditProd] = useState(null);
  const [selectedProduit, setSelectedProduit] = useState(INITIAL_PRODUITS[0]);
  const [qte, setQte] = useState('1');
  const [newNom, setNewNom] = useState('');
  const [newPrix, setNewPrix] = useState('');
  const [newStock, setNewStock] = useState('');

  const totalStock = produits.reduce((a,b)=>a+b.stock,0);
  const faibleStock = produits.filter(p=>p.stock<3).length;
  const revenuTotal = commandes.reduce((a,b)=>{ const n = parseInt(b.total.replace(/[^0-9]/g,''))||0; return a+n; },0);

  const creerCommande = () => {
    const q = parseInt(qte) || 1;
    const nouvelle = { id: Date.now().toString(), produit: selectedProduit.nom, image: selectedProduit.image, client: INITIAL_CLIENTS[0].nom, qte: q, total: (selectedProduit.prix * q).toLocaleString() + ' FCFA', date: new Date().toLocaleDateString() };
    setCommandes([nouvelle,...commandes]); setShowForm(false); setQte('1');
  };

  const demanderSuppression = (id, type, nom) => {
    setDeleteTarget({ id, type, nom });
    setShowDeleteModal(true);
  };

  const confirmerSuppression = () => {
    if(deleteTarget.type === 'produit') setProduits(produits.filter(p=>p.id!==deleteTarget.id));
    if(deleteTarget.type === 'commande') setCommandes(commandes.filter(c=>c.id!==deleteTarget.id));
    setShowDeleteModal(false);
  };

  const ouvrirEdit = (p) => { setEditProd(p); setNewNom(p.nom); setNewPrix(String(p.prix)); setNewStock(String(p.stock)); setShowProdForm(true); };
  const ouvrirAdd = () => { setEditProd(null); setNewNom(''); setNewPrix(''); setNewStock(''); setShowProdForm(true); };
  const sauverProduit = () => {
    if(!newNom ||!newPrix) return;
    const prix = parseInt(newPrix)||0;
    if(editProd){
      setProduits(produits.map(p=> p.id===editProd.id? {...p, nom: newNom, prix: prix, prixText: prix.toLocaleString()+' FCFA', stock: parseInt(newStock)||0 } : p));
    } else {
      const np = { id: Date.now().toString(), nom: newNom, prix: prix, prixText: prix.toLocaleString()+' FCFA', stock: parseInt(newStock)||0, image: 'https://images.unsplash.com/photo-1525598912003-663126343e1f?w=500', cat: 'Nouveau', color: '#EEF2FF' };
      setProduits([np,...produits]);
    }
    setShowProdForm(false);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.wrapper}>
        <View style={styles.phoneContainer}>
          <ScrollView style={styles.mainContent} contentContainerStyle={{ paddingBottom: 20 }}>
            {page==='dashboard' && (
              <>
                <Text style={styles.title}>MonTP</Text>
                <Text style={styles.subtitle}>Tableau de bord</Text>
                <View style={styles.row}>
                  <View style={[styles.statBox, { backgroundColor: '#4F46E5' }]}><Text style={styles.statLabel}>Revenu</Text><Text style={styles.statValue}>{revenuTotal.toLocaleString()} F</Text></View>
                  <View style={[styles.statBox, { backgroundColor: '#10B981' }]}><Text style={styles.statLabel}>Stock</Text><Text style={styles.statValue}>{totalStock}</Text></View>
                  <View style={[styles.statBox, { backgroundColor: '#F59E0B' }]}><Text style={styles.statLabel}>Clients</Text><Text style={styles.statValue}>{INITIAL_CLIENTS.length}</Text></View>
                </View>
                <View style={styles.stats2}><Text style={styles.statsText}>📦 Produits: {produits.length} | 🛒 Commandes: {commandes.length} | ⚠️ Faible: {faibleStock}</Text></View>
                <Text style={styles.alert}>⚠️ Faible stock : {faibleStock} - Cliquez pour commander</Text>
                <View style={styles.grid}>
                  {produits.slice(0,4).map(item => (
                    <TouchableOpacity key={item.id} onPress={() => { setSelectedProduit(item); setShowForm(true); setPage('commandes'); }} style={styles.productCard}>
                      <View style={[styles.imgBg, { backgroundColor: item.color }]}><Image source={{ uri: item.image }} style={styles.productImg} /></View>
                      <Text style={styles.cat}>{item.cat}</Text>
                      <Text style={styles.productName}>{item.nom}</Text>
                      <Text style={styles.productPrice}>{item.prixText}</Text>
                      <Text style={item.stock < 3? styles.low : styles.ok}>Stock: {item.stock}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </>
            )}
            {page==='produits' && (
              <>
                <View style={styles.headerRow}><Text style={styles.title}>Produits ({produits.length})</Text><TouchableOpacity onPress={ouvrirAdd} style={styles.btnSmall}><Text style={styles.btnWhite}>+ Ajouter</Text></TouchableOpacity></View>
                {produits.map(item => (
                  <View key={item.id} style={styles.prodListCard}>
                    <Image source={{ uri: item.image }} style={styles.listImg} />
                    <View style={{ flex:1 }}><Text style={styles.productName}>{item.nom}</Text><Text style={styles.productPrice}>{item.prixText} - Stock:{item.stock}</Text></View>
                    <TouchableOpacity onPress={()=>ouvrirEdit(item)} style={styles.iconBtn}><Text>✏️</Text></TouchableOpacity>
                    <TouchableOpacity onPress={()=>demanderSuppression(item.id,'produit',item.nom)} style={styles.iconBtn}><Text>🗑️</Text></TouchableOpacity>
                  </View>
                ))}
              </>
            )}
            {page==='clients' && (
              <>
                <Text style={styles.title}>Clients</Text>
                {INITIAL_CLIENTS.map(c => (
                  <View key={c.id} style={styles.clientCard}><View style={[styles.avatar, { backgroundColor: c.color }]}><Text style={styles.avatarText}>{c.initials}</Text></View><View style={{ flex: 1 }}><Text style={styles.clientName}>{c.nom}</Text><Text style={styles.clientCity}>{c.city} • {c.tel}</Text></View></View>
                ))}
              </>
            )}
            {page==='commandes' && (
              <>
                <Text style={styles.title}>Commandes ({commandes.length})</Text>
                {!showForm? (
                  <>
                    <TouchableOpacity onPress={() => setShowForm(true)} style={styles.btnBlue}><Text style={styles.btnWhite}>+ Créer une commande</Text></TouchableOpacity>
                    {commandes.length === 0? <View style={styles.empty}><Text style={{ fontSize: 50 }}>📦</Text><Text>Aucune commande</Text></View> : commandes.map(cmd => (
                      <View key={cmd.id} style={styles.orderCard}><Image source={{ uri: cmd.image }} style={styles.orderImg} /><View style={{ flex: 1 }}><Text style={styles.clientName}>{cmd.produit}</Text><Text style={styles.clientCity}>Qté: {cmd.qte} • {cmd.total}</Text></View><TouchableOpacity onPress={()=>demanderSuppression(cmd.id,'commande',cmd.produit)}><Text>🗑️</Text></TouchableOpacity></View>
                    ))}
                  </>
                ) : (
                  <View style={styles.form}>
                    <Text style={styles.formTitle}>Nouvelle Commande</Text>
                    <View style={styles.choiceWrap}>{produits.map(p => (<TouchableOpacity key={p.id} onPress={() => setSelectedProduit(p)} style={[styles.choice, selectedProduit.id === p.id && styles.choiceActive]}><Text style={selectedProduit.id === p.id? styles.choiceTextActive : styles.choiceText}>{p.nom}</Text></TouchableOpacity>))}</View>
                    <Text style={styles.label}>Quantité :</Text><TextInput value={qte} onChangeText={setQte} keyboardType="numeric" style={styles.input} />
                    <Text style={styles.total}>Total: {(selectedProduit.prix * (parseInt(qte) || 0)).toLocaleString()} FCFA</Text>
                    <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}><TouchableOpacity onPress={() => setShowForm(false)} style={styles.btnGray}><Text>Annuler</Text></TouchableOpacity><TouchableOpacity onPress={creerCommande} style={[styles.btnBlue, { flex: 1, margin:0 }]}><Text style={styles.btnWhite}>Confirmer</Text></TouchableOpacity></View>
                  </View>
                )}
              </>
            )}
          </ScrollView>
          <View style={styles.tabBar}>
            {[{ k: 'dashboard', l: 'Accueil' }, { k: 'produits', l: 'Produits' }, { k: 'clients', l: 'Clients' }, { k: 'commandes', l: 'Commandes' }].map(t => (
              <TouchableOpacity key={t.k} onPress={() => { setPage(t.k); setShowForm(false); }} style={styles.tab}><Text style={page === t.k? styles.tabActive : styles.tabInactive}>{t.l}</Text></TouchableOpacity>
            ))}
          </View>

          <Modal visible={showProdForm} transparent animationType="slide">
            <View style={styles.modalBg}><View style={styles.modalCard}>
              <Text style={styles.formTitle}>{editProd? 'Modifier Produit' : 'Ajouter Produit'}</Text>
              <Text style={styles.label}>Nom :</Text><TextInput value={newNom} onChangeText={setNewNom} style={styles.input} />
              <Text style={styles.label}>Prix :</Text><TextInput value={newPrix} onChangeText={setNewPrix} keyboardType="numeric" style={styles.input} />
              <Text style={styles.label}>Stock :</Text><TextInput value={newStock} onChangeText={setNewStock} keyboardType="numeric" style={styles.input} />
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 15 }}><TouchableOpacity onPress={()=>setShowProdForm(false)} style={styles.btnGray}><Text>Annuler</Text></TouchableOpacity><TouchableOpacity onPress={sauverProduit} style={[styles.btnBlue, { flex: 1, margin:0 }]}><Text style={styles.btnWhite}>{editProd? 'Modifier' : 'Ajouter'}</Text></TouchableOpacity></View>
            </View></View>
          </Modal>

          <Modal visible={showDeleteModal} transparent animationType="fade">
            <View style={styles.modalBg}><View style={styles.modalCard}>
              <Text style={styles.deleteTitle}>⚠️ Confirmation</Text>
              <Text style={styles.deleteText}>Voulez-vous vraiment supprimer{"\n"}"{deleteTarget.nom}"?</Text>
              <Text style={styles.deleteSub}>Cette action est irréversible.</Text>
              <View style={{ flexDirection: 'row', gap: 12, marginTop: 20 }}>
                <TouchableOpacity onPress={()=>setShowDeleteModal(false)} style={styles.btnNon}><Text style={styles.btnWhite}>Non</Text></TouchableOpacity>
                <TouchableOpacity onPress={confirmerSuppression} style={styles.btnOui}><Text style={styles.btnWhite}>Oui</Text></TouchableOpacity>
              </View>
            </View></View>
          </Modal>

        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#E5E7EB' },
  wrapper: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#E5E7EB', padding: 10 },
  phoneContainer: { width: '100%', maxWidth: 400, height: '95%', maxHeight: 850, backgroundColor: '#F9FAFB', borderRadius: 24, overflow: 'hidden', flexDirection: 'column' },
  mainContent: { flex: 1, backgroundColor: '#F9FAFB' },
  title: { fontSize: 22, fontWeight: 'bold', marginHorizontal: 15, marginTop: 15, color: '#111827' },
  subtitle: { fontSize: 12, color: '#6B7280', marginHorizontal: 15, marginBottom: 10 },
  row: { flexDirection: 'row', gap: 8, marginHorizontal: 15 },
  statBox: { flex: 1, padding: 10, borderRadius: 12 },
  statLabel: { color: 'white', opacity: 0.9, fontSize: 10 }, statValue: { color: 'white', fontSize: 13, fontWeight: 'bold', marginTop: 3 },
  stats2: { backgroundColor: 'white', margin: 15, padding: 8, borderRadius: 8 },
  statsText: { fontSize: 11, color: '#374151' },
  alert: { marginHorizontal: 15, marginBottom: 8, color: '#4F46E5', fontWeight: 'bold', backgroundColor: '#EEF2FF', padding: 7, borderRadius: 7, fontSize: 10 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', padding: 8 },
  productCard: { width: '46%', backgroundColor: 'white', margin: '2%', borderRadius: 10, padding: 8 },
  imgBg: { borderRadius: 8, padding: 3, alignItems: 'center' },
  productImg: { width: '100%', height: 60, borderRadius: 6, resizeMode: 'contain' },
  cat: { marginTop: 4, color: '#9CA3AF', fontSize: 8 }, productName: { fontWeight: 'bold', color: '#111827', fontSize: 11 }, productPrice: { color: '#4F46E5', fontWeight: 'bold', fontSize: 10 }, low: { color: '#EF4444', fontSize: 9 }, ok: { color: '#10B981', fontSize: 9 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginRight: 15 },
  btnSmall: { backgroundColor: '#4F46E5', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6 },
  prodListCard: { flexDirection: 'row', backgroundColor: 'white', padding: 8, borderRadius: 8, marginBottom: 6, marginHorizontal: 15, alignItems: 'center' },
  listImg: { width: 45, height: 45, borderRadius: 6, marginRight: 8 },
  iconBtn: { padding: 6, marginLeft: 3 },
  clientCard: { flexDirection: 'row', backgroundColor: 'white', padding: 10, borderRadius: 10, marginBottom: 6, marginHorizontal: 15, alignItems: 'center' },
  avatar: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', marginRight: 8 },
  avatarText: { color: 'white', fontWeight: 'bold', fontSize: 13 },
  clientName: { fontWeight: 'bold', fontSize: 12 }, clientCity: { color: '#6B7280', fontSize: 10 },
  btnBlue: { backgroundColor: '#4F46E5', padding: 10, borderRadius: 8, alignItems: 'center', margin: 15 },
  btnWhite: { color: 'white', fontWeight: 'bold', fontSize: 12 },
  btnGray: { backgroundColor: '#E5E7EB', padding: 10, borderRadius: 8, alignItems: 'center', flex: 1 },
  empty: { alignItems: 'center', marginTop: 30 },
  orderCard: { flexDirection: 'row', backgroundColor: 'white', padding: 8, borderRadius: 8, marginBottom: 6, marginHorizontal: 15, alignItems: 'center' },
  orderImg: { width: 40, height: 40, borderRadius: 6, marginRight: 8 },
  form: { backgroundColor: 'white', padding: 12, borderRadius: 10, margin: 15 },
  formTitle: { fontSize: 14, fontWeight: 'bold', marginBottom: 8 },
  label: { fontWeight: 'bold', marginBottom: 3, marginTop: 6, fontSize: 11 },
  choiceWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 5, marginBottom: 6 },
  choice: { borderWidth: 1, borderColor: '#D1D5DB', paddingHorizontal: 7, paddingVertical: 4, borderRadius: 10 },
  choiceActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  choiceText: { fontSize: 9, color: '#374151' }, choiceTextActive: { fontSize: 9, color: 'white' },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 6, padding: 7, fontSize: 12 },
  total: { fontWeight: 'bold', marginTop: 6, fontSize: 12, color: '#4F46E5' },
  tabBar: { flexDirection: 'row', backgroundColor: 'white', paddingVertical: 10, borderTopWidth: 1, borderColor: '#E5E7EB' },
  tab: { flex: 1, alignItems: 'center' },
  tabInactive: { color: '#9CA3AF', fontSize: 10 }, tabActive: { color: '#4F46E5', fontWeight: 'bold', fontSize: 10 },
  modalBg: { flex:1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalCard: { backgroundColor: 'white', borderRadius: 14, padding: 18 },
  deleteTitle: { fontSize: 16, fontWeight: 'bold', textAlign: 'center', color: '#EF4444' },
  deleteText: { fontSize: 14, textAlign: 'center', marginTop: 10, color: '#111827', fontWeight: 'bold' },
  deleteSub: { fontSize: 11, textAlign: 'center', marginTop: 5, color: '#6B7280' },
  btnOui: { backgroundColor: '#10B981', padding: 12, borderRadius: 10, alignItems: 'center', flex: 1 },
  btnNon: { backgroundColor: '#4F46E5', padding: 12, borderRadius: 10, alignItems: 'center', flex: 1 },
});