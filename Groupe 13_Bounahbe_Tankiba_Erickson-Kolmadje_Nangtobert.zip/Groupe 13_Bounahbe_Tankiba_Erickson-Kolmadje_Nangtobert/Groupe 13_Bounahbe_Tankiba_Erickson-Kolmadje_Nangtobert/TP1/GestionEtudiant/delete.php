<?php
require 'config.php';
$id = $_GET['id'] ?? '';
if(!$id){
    header('Location: index.php');
    exit;
}

// Si l'utilisateur a cliqué sur OUI, on supprime vraiment
if(isset($_GET['confirm']) && $_GET['confirm'] == 'oui'){
    $pdo->prepare('DELETE FROM etudiant WHERE idEtu=?')->execute([$id]);
    header('Location: index.php');
    exit;
}

// On récupère l'étudiant pour afficher son nom dans la confirmation
$stmt = $pdo->prepare('SELECT * FROM etudiant WHERE idEtu=?');
$stmt->execute([$id]);
$etu = $stmt->fetch();
if(!$etu){
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Confirmation Suppression</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
body{background:#f0f6ff}
.header{background:linear-gradient(90deg,#0a7ac7,#16b4f0);color:white;padding:12px 35px;display:flex;justify-content:space-between;align-items:center}
.header .logo{color:#d4ff00;font-weight:bold;font-size:18px}
.header nav a{color:white;text-decoration:none;margin-left:18px;font-size:14px}
.hero{background:linear-gradient(90deg,#0a7ac7,#2ec0ff);padding:30px 35px;color:white}
.hero h1{font-size:24px}
.container{display:flex;justify-content:center;padding:40px 20px}
.card{background:white;width:100%;max-width:500px;border-radius:12px;padding:35px;box-shadow:0 12px 30px rgba(0,0,0,.15);text-align:center}
.icon{width:65px;height:65px;background:#ffeaea;color:#d9534f;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:32px;margin:0 auto 15px auto}
.card h3{color:#c0392b;margin-bottom:10px}
.card p{color:#555;font-size:14px;line-height:1.5}
.student-name{background:#f7fbff;border:1px dashed #0a7ac7;padding:12px;border-radius:8px;margin:20px 0;font-weight:bold;color:#0a3a5a}
.btns{display:flex;gap:12px;margin-top:25px}
.btn{flex:1;padding:13px;border-radius:8px;text-decoration:none;font-weight:bold;text-align:center;border:none;cursor:pointer;font-size:14px}
.btn-oui{background:#d9534f;color:white}
.btn-non{background:#eef2f7;color:#333}
</style>
</head>
<body>

<div class="header">
    <div class="logo">Université de Moundou</div>
    <nav>
        <a href="index.php">Liste des Étudiants</a>
        <a href="form.php">Ajouter un nouveau Étudiant</a>
    </nav>
</div>

<div class="hero">
    <h1>Confirmation de suppression</h1>
</div>

<div class="container">
    <div class="card">
        <div class="icon">!</div>
        <h3>Voulez-vous vraiment supprimer l'étudiant ?</h3>
        <p>Cette action est irréversible. Les données de l'étudiant seront définitivement supprimées.</p>
        
        <div class="student-name">
            <?= htmlspecialchars($etu['nomEtu'].' '.$etu['prenomEtu']) ?><br>
            <span style="font-weight:normal;font-size:12px;color:gray"><?= htmlspecialchars($etu['idEtu']) ?> - <?= htmlspecialchars($etu['mentionEtu']) ?></span>
        </div>

        <div class="btns">
            <a href="index.php" class="btn btn-non">Non, annuler</a>
            <a href="delete.php?id=<?= htmlspecialchars($id) ?>&confirm=oui" class="btn btn-oui">Oui, supprimer</a>
        </div>
    </div>
</div>

</body>
</html>