adocument.getElementById('formEtu')?.addEventListener('submit', function(e){
  let phone = this.numTelEtu.value.replace(/\s+/g,'');
  if(phone.length < 8 || isNaN(phone)){ alert('Téléphone invalide : entrez seulement des chiffres, 8 à 9 chiffres minimum'); e.preventDefault(); return false; }
});