<?php
require 'config.php';
$etudiants = $pdo->query('SELECT * FROM etudiant ORDER BY idEtu DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>TP1</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial}
body{background:#eef4ff}
.header{background:#083d77;color:white;padding:12px 25px;display:flex;justify-content:space-between}
.header a{color:white;text-decoration:none;margin-left:15px;font-size:13px}
.hero{background:#0a5bb5;color:white;padding:20px 25px}
.box{max-width:1250px;margin:15px auto;background:white;padding:15px;border-radius:10px;overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:1000px}
th{background:#083d77;color:white;padding:8px;font-size:11px}
td{padding:8px;border-bottom:1px solid #eee;font-size:12px;text-align:center}
.btn{padding:4px 8px;border-radius:4px;color:white;text-decoration:none;font-size:11px}
.edit{background:orange}.del{background:red}
.add{background:#083d77;color:white;padding:8px 15px;border-radius:6px;text-decoration:none;font-size:13px;font-weight:bold}
</style>
</head>
<body>
<div class="header"><b>TP1 - Gestion Etudiants</b><div><a href="index.php">Tableau de bord</a><a href="form.php">Nouvelle inscription</a></div></div>
<div class="hero"><h3>Liste des Etudiants (<?= count($etudiants) ?>)</h3></div>
<div class="box">
<div style="display:flex;justify-content:space-between;margin-bottom:10px"><b>Base complete</b><a href="form.php" class="add">+ Ajouter un nouveau Etudiant</a></div>
<table>
<tr><th>Matricule</th><th>Nom</th><th>Email</th><th>Region</th><th>Departement</th><th>Arrondissement</th><th>Cycle</th><th>Mention</th><th>Parcours</th><th>Actions</th></tr>
<?php foreach($etudiants as $e): ?>
<tr>
<td><?= htmlspecialchars($e['idEtu']) ?></td>
<td><?= htmlspecialchars($e['nomEtu'].' '.$e['prenomEtu']) ?></td>
<td><?= htmlspecialchars($e['emailEtu']) ?></td>
<td><?= htmlspecialchars($e['regEtu']) ?></td>
<td><?= htmlspecialchars($e['departEtu']) ?></td>
<td><?= htmlspecialchars($e['arrondisEtu']) ?></td>
<td><?= htmlspecialchars($e['cycleEtu']) ?></td>
<td><?= htmlspecialchars($e['mentionEtu']) ?></td>
<td><?= htmlspecialchars($e['ParcoursEtu']) ?></td>
<td><a href="form.php?id=<?= $e['idEtu'] ?>" class="btn edit">Modifier</a> <a href="delete.php?id=<?= $e['idEtu'] ?>" class="btn del">Supprimer</a></td>
</tr>
<?php endforeach; ?>
</table>
</div>
</body>
</html>