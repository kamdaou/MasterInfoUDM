<?php
/** TP1 - CREATE et UPDATE : traitement POST */
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
    http_response_code(405); 
    exit('Méthode non autorisée.'); 
}

// Revalidation serveur
$d = [];
foreach (CHAMPS as $c) {
    $d[$c] = trim($_POST[$c] ?? '');
    if ($d[$c] === '') { 
        header('Location: index.php?err=' . urlencode("Champ manquant : $c")); 
        exit; 
    }
}
if (!filter_var($d['emailEtu'], FILTER_VALIDATE_EMAIL)) {
    header('Location: index.php?err=' . urlencode('Email invalide.')); 
    exit;
}

try {
    if (($_POST['mode'] ?? '') === 'update') {
        $set = implode(', ', array_map(fn($c) => "$c = :$c", array_diff(CHAMPS, ['idEtu'])));
        $sql = "UPDATE etudiant SET $set WHERE idEtu = :idEtu";
        $pdo->prepare($sql)->execute($d);
    } else {
        $cols = implode(', ', CHAMPS);
        $params = implode(', ', array_map(fn($c) => ":$c", CHAMPS));
        $sql = "INSERT INTO etudiant ($cols) VALUES ($params)";
        $pdo->prepare($sql)->execute($d);
    }
    header('Location: index.php?ok=1');
    exit;
} catch (PDOException $e) {
    error_log($e->getMessage());
    $msg = ($e->getCode() === '23000') ? 'Matricule ou email déjà utilisé.' : 'Erreur enregistrement : ' . $e->getMessage();
    header('Location: index.php?err=' . urlencode($msg));
    exit;
}
?>